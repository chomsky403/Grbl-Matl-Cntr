'use strict';

module.exports = function isEmpty() {
  return !this.items.length;
};
