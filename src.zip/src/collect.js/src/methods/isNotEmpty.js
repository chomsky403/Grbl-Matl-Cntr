'use strict';

module.exports = function isNotEmpty() {
  return !!this.items.length;
};
