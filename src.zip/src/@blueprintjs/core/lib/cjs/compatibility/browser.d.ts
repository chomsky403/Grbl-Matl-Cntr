export declare const Browser: {
    isEdge: () => boolean;
    isInternetExplorer: () => boolean;
    isWebkit: () => boolean;
};
