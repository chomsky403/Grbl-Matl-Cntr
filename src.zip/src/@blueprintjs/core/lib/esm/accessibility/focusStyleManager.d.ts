export declare const FocusStyleManager: {
    alwaysShowFocus: () => boolean | void;
    isActive: () => boolean;
    onlyShowFocusOnTabs: () => boolean | void;
};
