export declare function isDarkTheme(element: Element | Text | null): boolean;
